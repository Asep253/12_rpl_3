<?php
session_start();
if (isset($_SESSION['success_message'])) {
    echo "<script>alert('" . $_SESSION['success_message'] . "');</script>";
    unset($_SESSION['success_message']);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>LoginWongBelanja</title>
   <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet">
	<link rel="stylesheet"  href="assets/css/login.css">
  
</head>
<body>
<h2>Login/Daftar</h2>
<div class="container" id="container">
	<div class="form-container sign-up-container">
		<form action="controllers/user.php?aksi=register" method="post">
			<h1>Daftar</h1>
			<span>Buat Akun</span>
			<span></span>
			<input  name="Username" placeholder="Username" type="text" required="">
			<input  name="NamaLengkap" placeholder="Nama Lengkap" type="text" required="">
         	<input name="Password" placeholder="Password" type="password" required="">
			 <label for="role">Pilih Role:</label><br>
			<select id="role" name="role" required>
				<option value="">-- Pilih Role --</option>
				<option value="pengguna">Pengguna</option>
				<option value="admin">Admin</option>
			</select><br><br>
         <button  type="submit" name="register" >Daftar</button>
		</form>
	</div>
	<div class="form-container sign-in-container">
   <form action="controllers/user.php?aksi=login" method="post">
			<h1>Login</h1>
			
			<span>Masuk Akun</span>
			<input name="Username" placeholder="Username">
			<input name="Password" placeholder="Password" type="password" required="">
			<!-- <a href="#">Forgot your password?</a> -->
			<button type="submit" name="login" >Login</button>
		</form>
	</div>
	<div class="overlay-container">
		<div class="overlay">
			<div class="overlay-panel overlay-left">
				<h1>Haii lagi</h1>
				<p>Untuk Tetap Terhubung Dengan Kami Gunakan Akun personal kamu</p>
				<button class="ghost" id="signIn">Login</button>
			</div>
			<div class="overlay-panel overlay-right">
				<h1>Hello!</h1>
				<p>Buat Akun Kamu Agar Terhubung Dengan Kami</p>
				<button class="ghost" id="signUp">Daftar</button>
			</div>
		</div>
	</div>
</div>

</body>
<script>const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

signUpButton.addEventListener('click', () => {
	container.classList.add("right-panel-active");
});

signInButton.addEventListener('click', () => {
	container.classList.remove("right-panel-active");
});
</script>

	</html>