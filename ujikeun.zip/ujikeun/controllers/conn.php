<?php
session_start();
//membuat class database
class database
{
	//koneksi database
	private $host = "sql302.infinityfree.com";
	private $uname = "if0_38745707";
	private $pass = "WvvMZdGLc1X";
	private $db = "if0_38745707_db_kasir";
	public $koneksi;

	function __construct()
	//fungsi membuka koneksi ke database mysql dengan menggunakan informasi yang telah kita tentukan diatas
	{

		$this->koneksi = mysqli_connect($this->host, $this->uname, $this->pass);
		mysqli_select_db($this->koneksi, $this->db);

		if ($this->koneksi) {
			// echo "Koneksi database mysql dan php berhasil.";
			return $this->koneksi;
		} else {
			echo "Koneksi database mysql dan php GAGAL !";
		}
	}
}

$conn = new database();