<?php
//memanggil
include_once __DIR__ . '/../models/barang.php';

// membuat objek
$barang = new Barang();

try {
    //fungsi tambah
    if (!empty($_GET['aksi'])) {
        if ($_GET['aksi'] == 'tambah' && isset($_POST['tambah'])) {
            $NamaBarang = $_POST['NamaBarang'];
            $Harga = $_POST['Harga'];
            $Besarandiskon = $_POST['Besarandiskon'];
            // $stok = $_POST['stok'];
            $barang->TambahBarang($NamaBarang, $Harga, $Besarandiskon, $stok);
            //fungsi hapus
        } elseif ($_GET['aksi'] == 'hapus') {
            $id = $_GET['IdBarang'];
            $hapus = $barang->Hapus($id);
            if ($hapus) {
                header("Location: ../views/barang.php");
            } else {
                echo "<script>alert('Data Gagal Dihapus');window.location='../views/barang.php'</script>";
            }
            //fungsi edit
        } elseif ($_GET['aksi'] == 'edit' && isset($_POST['edit'])) {
            $id = $_POST['IdBarang']; 
            $NamaBarang = $_POST['NamaBarang'];
            $Harga = $_POST['Harga'];
            $Besarandiskon = $_POST['Besarandiskon'];
            // $stok = $_POST['stok'];
             $barang->Edit($id, $NamaBarang, $Harga, $Besarandiskon, $stok);
        }
    } else {
        $totals = $barang->HitungBarang();
        $transaksi = $barang->HitungTransaksi();
        $barangs = $barang->TampilData();
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
//memanggil
include_once __DIR__ . '/../models/barang.php';

// membuat objek
$barang = new Barang();

try {
    //fungsi tambah
    if (!empty($_GET['aksi'])) {
        if ($_GET['aksi'] == 'tambah' && isset($_POST['tambah'])) {
            $NamaBarang = $_POST['NamaBarang'];
            $Harga = $_POST['Harga'];
            $Besarandiskon = $_POST['Besarandiskon'];
            // $stok = $_POST['stok'];
            $barang->TambahBarang($NamaBarang, $Harga, $Besarandiskon, $stok);
            //fungsi hapus
        } elseif ($_GET['aksi'] == 'hapus') {
            $id = $_GET['IdBarang'];
            $hapus = $barang->Hapus($id);
            if ($hapus) {
                header("Location: ../views/barang.php");
            } else {
                echo "<script>alert('Data Gagal Dihapus');window.location='../views/barang.php'</script>";
            }
            //fungsi edit
        } elseif ($_GET['aksi'] == 'edit' && isset($_POST['edit'])) {
            $id = $_POST['IdBarang']; 
            $NamaBarang = $_POST['NamaBarang'];
            $Harga = $_POST['Harga'];
            $Besarandiskon = $_POST['Besarandiskon'];
            // $stok = $_POST['stok'];
             $barang->Edit($id, $NamaBarang, $Harga, $Besarandiskon, $stok);
        }
    } else {
        $totals = $barang->HitungBarang();
        $transaksi = $barang->HitungTransaksi();
        $barangs = $barang->TampilData();
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}