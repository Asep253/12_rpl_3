<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"  crossorigin="anonymous">
    <title>Transaction</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        .container-fluid{
            background-color: grey;
            border-radius: 5px;
        }  
    </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg fixed-top text-dark p-3">
    <div class="container-fluid">
    <h6 class="navbar-brand fw-bolder text-primary text-black"  href="#">Wong Belanja</h6>
    <i class="bi bi-basket2 text-dark"></i>
          <div class="button-container">
         
          <a href="../home.php" class="fs-3">
          <i class="fas fa-home text-dark"></i>
          </a>
          <a href="views/cart.php" class="fs-3">
          <i class="fas fa-cart-plus text-dark"></i>
          </a>

          <a href="../logout.php" onclick="return confirm('Yakin ingin keluar dari aplikasi?')" class="fs-3">
          <i class="fas fa-sign-out-alt text-dark"></i>
          </a>
          </div>
 
        </div>
    </div>
</nav>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/scroll.js"></script>
</body>
</html>