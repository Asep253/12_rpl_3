<?php
include_once 'layouts/admin.php';
include_once '../controllers/barang.php';
?>
<main>
  <?php 
  //untuk menampilkan daftar barang yang ada dalam array atau objek $barangs
  if (empty($barangs)) { 
    echo"<br><br><br><h2>Tidak Ada Barang</h2>";
    ?>
  <?php } else { ?>
    <?php foreach ($barangs as $x): ?>
      <br><br><br>
      <div class="card mb-3">
        <div class="card-body">
          <h5 class="card-title"><?= $x->NamaBarang ?></h5>
          <p class="card-text">Rp.<?= number_format($x->Harga, 0, ',', '.') ?></p>
        </div>
      </div>
    <?php endforeach; ?>
  <?php } ?>
</main>