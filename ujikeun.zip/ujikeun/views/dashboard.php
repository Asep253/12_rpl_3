<?php
include_once 'layouts/admin.php';
include_once '../controllers/barang.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<main>
<br><br><br><br>
<div class="row">
  <div class="col-sm-6 mb-3 mb-sm-0">
    <div class="card">
      <div class="card-body text-bg-light "> Barang Tersedia : <?= $totals ?></div>
        <div class="card-footer d-flex align-items-center justify-content-between text-bg-secondary">
          <a class="small text-white stretched-link " href="display.php">View Details</a>
            <div class="small text-white">
                <svg class="svg-inline--fa fa-angle-right" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512">
                    <path fill="currentColor" d="M246.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L178.7 256 41.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                </svg>
            </div>
        </div>
    </div>
</div>

<div class="col-sm-6">
    <div class="card">
      <div class="card-body text-bg-light">Barang Terjual : <?= $transaksi ?> </div>
        <div class="card-footer d-flex align-items-center justify-content-between text-bg-secondary">
        <a class="small text-white stretched-link" href="terjual.php">View Details</a>
            <div class="small text-white">
                <svg class="svg-inline--fa fa-angle-right" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512">
                    <path fill="currentColor" d="M246.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L178.7 256 41.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                </svg>
            </div>
        </div>
    </div>
</div>


</div>
</main>
</body>
</html>