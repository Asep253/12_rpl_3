<?php
include_once 'layouts/header.php';
include_once '../controllers/transaksi.php';
//digunakan untuk menyimpan dan mengakses data yang akan tersedia selama sesi (session) berlangsung
$UserId = $_SESSION['data']['IdUser']; 
$result = $transaksi->TampilTransaksi($UserId);
?>

<main>
<!--untuk menampilkan detail transaksi atau pesanan.-->
    <?php if (empty($result)) { ?>
        <br><br><br>
        <h2>Tidak Ada Transaksi</h2>
    <?php } else { ?>
        <?php foreach ($result as $x): ?>
            <br><br><br>
            <div class="card mb-3">
                <div class="card-body m-3">
                    <h2>DETAIL PESANAN ANDA :</h2>
                    <h5 class="mt-3 card-title">Atas Nama: <?= $x->Username ?></h5>
                    <h5 class="mt-3 card-title">Nama Barang: <?= $x->NamaBarang ?></h5>
                    <h5 class="mt-3 card-text">Harga Satuan: Rp.<?= number_format($x->Harga, 0, ',', '.') ?></h5>
                    <h5 class="mt-3">Jumlah: <?= $x->Jumlah ?></h5>
                    <!-- <h5 class="mt-3">Diskon Di Dapatkan: <?= $x->Besarandiskon ?></h5> -->
                    <h5 class="mt-3">Total Harga Pembelian: Rp.<?= number_format($x->TotalHarga, 0, ',', '.') ?></h5>
                </div>
            </div>
        <?php endforeach; ?>
    <?php } ?>
</main>